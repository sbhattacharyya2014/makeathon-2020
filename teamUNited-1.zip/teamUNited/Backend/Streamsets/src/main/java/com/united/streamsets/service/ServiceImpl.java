package com.united.streamsets.service;

import com.united.streamsets.entity.PipelineDetail;
import com.united.streamsets.repository.PipelinesJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.Optional;

@Component
@Transactional
public class ServiceImpl {

    @Autowired
    PipelinesJpaRepository pipelinesJpaRepository;

    @Autowired
    StreamsetService streamsetService;

    public PipelineDetail findById(String pipelineId)
    {
        Optional<PipelineDetail> pipelineDetail = pipelinesJpaRepository.findById(pipelineId);
        if(pipelineDetail.isPresent())
        {
            return  pipelineDetail.get();
        }
        return  null;

    }

    public void deletePipeLineById(String pipelineId)
    {
        PipelineDetail pipelineDetail = findById(pipelineId);
        if(pipelineDetail!=null) {
            pipelinesJpaRepository.delete(pipelineDetail);

            streamsetService.deletePipeline(pipelineId);
        }

    }

}

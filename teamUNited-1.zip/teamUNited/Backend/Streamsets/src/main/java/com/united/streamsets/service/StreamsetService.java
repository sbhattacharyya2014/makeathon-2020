package com.united.streamsets.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.united.streamsets.repository.PipelinesJpaRepository;

@Service
public class StreamsetService {
	@Value("${streamSets.URL}")
	String streamsetUrl;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	PipelinesJpaRepository pipelineRepository;
	
	public ResponseEntity<String> getPipeLineCount() {
		return restTemplate.getForEntity(streamsetUrl + "/pipelines/count", String.class);
	}

	public ResponseEntity<String>getAllPipeLine() {
		return restTemplate.getForEntity(streamsetUrl + "/pipelines", String.class);
	}

	public ResponseEntity<String>getAlerts() {
		return restTemplate.getForEntity(streamsetUrl + "/pipelines/status", String.class);
	}




	public ResponseEntity<String>getMetrics(String pipelineId) {
		HashMap<String,String> map = new HashMap<>();
		map.put("pipelineId",pipelineId);
		return restTemplate.getForEntity(streamsetUrl + "/pipeline/{pipelineId}/metrics", String.class,map);
	}


	public void deletePipeline(String pipelineId)
	{
		restTemplate.getForEntity(streamsetUrl + "/pipeline/{pipelineId}/history", String.class);
	}

}

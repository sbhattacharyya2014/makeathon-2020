package com.united.streamsets.controller;

import java.util.Arrays;
import java.util.List;

import com.united.streamsets.service.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.united.streamsets.service.StreamsetService;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3000")
public class StreamsetController {

	@Autowired
	private StreamsetService streamsetService;
	
	@Autowired
	ServiceImpl serviceimpl;
	
	@GetMapping("pipelines_count")
	public ResponseEntity<String> getPipelineCount(){
		return streamsetService.getPipeLineCount();
	}

	@GetMapping("pipelines")
	public ResponseEntity<String>getAllPipeline(){
		return streamsetService.getAllPipeLine();
	}

	@GetMapping("alerts")
	public ResponseEntity<String>getAlerts(){
		return streamsetService.getAlerts();
	}

	@GetMapping("{pipelineId}")
	public ResponseEntity<String> getMetrics(@PathVariable String pipelineId){
		return streamsetService.getMetrics(pipelineId);
	}

}

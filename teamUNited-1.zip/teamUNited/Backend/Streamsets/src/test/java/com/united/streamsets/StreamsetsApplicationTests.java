package com.united.streamsets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamsetsApplicationTests {

	@Test
	void contextLoads() {
	}

}

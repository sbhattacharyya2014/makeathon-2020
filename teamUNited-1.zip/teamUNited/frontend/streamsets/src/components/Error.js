import React from 'react';


const Error = () => {
    return (
        <div>
         Please check the logs as there is some error !!!
        </div>
    );
}

export default Error;
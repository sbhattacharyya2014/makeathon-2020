import React from 'react';

class Pipeline extends React.Component {

    onSave=()=>{
        console.log("button clicked")
    }

    componentDidMount()
    {
    
            console.log(this.props.id)
    }
    render() {
        return (
            <div>
                {/* <h1></h1>
                <div className="container">
                    <fieldset className="form-group">
                        <label>Description</label>
                        <input type="text" className="form-control" name="description" required="required"></input>
                    </fieldset>
                    <fieldset>
                        <label>Configure</label>
                        <input type="text" className="form-control" name="description" required="required"></input>
                    </fieldset>
                    <br></br>
                    <button className="btn btn-success" onClick={this.onSave}>Save</button>
                </div> */}
             
            </div>
        )
    }
}

export default Pipeline;
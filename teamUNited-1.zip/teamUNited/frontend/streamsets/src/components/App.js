import React from 'react';
import Home from './Home';
import Header from './Header';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import Error from './Error';
import './App.css';
import './bootstrap.css';
import PipeLine from './PipeLine';
import PipeLineList from './PipeLineList';

class App extends React.Component{
render()
{
    return(
        <div className="">
        <div>
            <Router>
                <>
                <Header/>
                <Switch>
                <Route path="/" exact component={Home}></Route>
                <Route path="/home" component={Home}></Route>
                <Route path="/pipeline" component={PipeLineList}></Route>
                
                <Route path="/error" component={Error}></Route>
                </Switch> 
             
                </>
            </Router>
        </div>
        </div>
    );
}

}

export default App;
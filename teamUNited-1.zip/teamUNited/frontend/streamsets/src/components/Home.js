import React from 'react';
import './App.css'
import './bootstrap.css';
import service from '../api/PipelinseService.js';
import pipeline from '../api/PipelinseService';

class Home extends React.Component {

    state = {
        pipeline: [
      
        ]
    }

    componentDidMount() {
        service.pipelineService()
            .then(response => {

                this.setState({ pipeline: response.data })
                console.log("hello component did mount", pipeline)
            })
            .catch(error => {
                console.log("some error has occurred", error.message)
                this.props.history.push("/error")
            }

            )

        setInterval(2000);
    }


    // componentDidUpdate(){
    //     service.pipelineService()
    //         .then(response => { 

    //             this.setState({ pipeline: response.data })
    //             console.log("")
    //          }) .catch(error=>{
    //             console.log("some error has occurred",error.message)
    //              this.props.history.push("/error")
    //             }


    //             )
    // }

    startPipeline = (id) => {
        console.log('start ' + id)
        this.props.history.push("/home")
    }

    stopPipeline = (id) => {
        console.log('stop ' + id)
        this.props.history.push("/home")
    }

    configurePipeLine = (id) => {
        console.log('update ' + id)
        this.props.history.push(`/pipeline/${id}`)
    }

    render() {
        return (

            <div>

                <table className="table table-light">
                    <thead >
                        <tr>
                            <th>
                                <div className="custom-control custom-checkbox">
                                    <input type="checkbox" className="custom-control-input" />
                                    <label className="custom-control-label"></label>
                                </div>
                            </th>
                            <th>Title</th>
                            <th>PipeLineId</th>
                            <th>Description</th>
                            <th>Start</th>
                            <th>Stop</th>
                            <th>Configure</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.pipeline.map(pipe =>

                            <tr key={pipe.pipelineId}>
                                <th scope="col">
                                    <div className="custom-control custom-checkbox">
                                        <input type="checkbox" className="custom-control-input" />
                                        <label className="custom-control-label"></label>
                                    </div>
                                </th>
                                <td>{pipe.title}</td>
                                <td>{pipe.pipelineId}</td>
                                <td>{pipe.description}</td>
                                <td><button className="btn btn-success" onClick={() => { this.startPipeline(pipe.pipelineId) }}>Start</button></td>
                                <td><button className="btn btn-danger" onClick={() => { this.stopPipeline(pipe.pipelineId) }}>Stop</button></td>
                                <td><button className="btn btn-warning" onClick={() => { this.configurePipeLine(pipe.pipelineId) }}>Configure</button></td>

                            </tr>
                        )
                        }
                    </tbody>
                </table>
               
            </div>
        )
    }
}

export default Home;
import axios from "axios";

class PipelineService{

    helloService(name)
    {
       return  axios.get(`http://localhost:8080/hello/${name}`);
    }

    // pipelineService()
    // {
    //     return (axios.get('http://037bf9dc07c2.ngrok.io/rest/v1/pipeline/samplepipeline'));
   
        
    // }

    pipelineService(name)
    {
       return  axios.get('http://localhost:8080/pipelines');
    }

    //startPipeLineService
    startPipelineService(name)
    {
       return  axios.get('http://localhost:8080/pipelines');
    }

     //stopPipeLineService
     startPipelineService(name)
     {
        return  axios.get('http://localhost:8080/pipelines');
     }

    // deletePipelineService
    deleltePipelineService(name)
    {
       return  axios.get('http://localhost:8080/pipelines');
    }
   //  helloService()
   //  {
   //     return  axios.get('http://localhost:8080/pipelines');
   //  }

}

export default new PipelineService();